package com.example.foodapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button ChickenButton;
    private Button FishButton;
    private Button SteakButton;
    private Button CheckoutButton;
    int TotalPayment=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ChickenButton=(Button)findViewById(R.id.Chicken);
        ChickenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenChickenMenu();
            }
        });

        FishButton=(Button)findViewById(R.id.Fish);
        FishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenFishMenu();
            }
        });

        SteakButton=(Button)findViewById(R.id.Steak);
        SteakButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenSteakMenu();
            }
        });

        CheckoutButton=(Button)findViewById(R.id.Checkout);
        CheckoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenCheckout();
            }
        });



    }

    public void OpenChickenMenu(){
        Intent i = new Intent(this,ChickenMenu.class);
        startActivityForResult(i,1001);
    }

    public void OpenFishMenu(){
        Intent i = new Intent(this,FishMenu.class);
        startActivityForResult(i,1002);
    }

    public void OpenSteakMenu(){
        Intent i = new Intent(this,SteakMenu.class);
        startActivityForResult(i,1003);
    }

    public void OpenCheckout(){
        Intent i = new Intent(this,CheckoutMenu.class);
        i.putExtra("Tpayment",TotalPayment);
        startActivity(i);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch(requestCode){
            case 1001:
                if (resultCode == Activity.RESULT_OK){
                    int FoodPrice=data.getIntExtra("ChickenPrice",0);
                    TotalPayment=TotalPayment+FoodPrice;

                }
                break;

            case 1002:
                if (resultCode == Activity.RESULT_OK){
                    int FoodPrice=data.getIntExtra("FishPrice",0);
                    TotalPayment=TotalPayment+FoodPrice;

                }
                break;

            case 1003:
                if (resultCode == Activity.RESULT_OK){
                    int FoodPrice=data.getIntExtra("SteakPrice",0);
                    TotalPayment=TotalPayment+FoodPrice;

                }
                break;

        }
    }
}