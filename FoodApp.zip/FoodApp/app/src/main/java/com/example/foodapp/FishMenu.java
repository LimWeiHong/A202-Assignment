package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FishMenu extends AppCompatActivity {
    private Button AddtocartFish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fish_menu);

        AddtocartFish=(Button)findViewById(R.id.AddToCartFish);
        AddtocartFish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenAddtocartFish();
            }
        });
    }

    public void OpenAddtocartFish(){
        Intent i = new Intent ();
        i.putExtra("FishPrice", 12);
        setResult(Activity.RESULT_OK,i);
        finish();
    }
}