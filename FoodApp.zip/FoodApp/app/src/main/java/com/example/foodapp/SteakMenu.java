package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SteakMenu extends AppCompatActivity {
    private Button AddtocartSteak;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_steak_menu);

        AddtocartSteak=(Button)findViewById(R.id.AddToCartSteak);
        AddtocartSteak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenAddtocartSteak();
            }
        });
    }

    public void OpenAddtocartSteak(){
        Intent i = new Intent ();
        i.putExtra("SteakPrice", 18);
        setResult(Activity.RESULT_OK,i);
        finish();
    }
}