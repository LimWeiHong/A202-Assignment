package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ChickenMenu extends AppCompatActivity {
    private Button AddtocartChicken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chicken_menu);

        AddtocartChicken=(Button)findViewById(R.id.AddToCartChicken);
        AddtocartChicken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenAddtocartChicken();
            }
        });

    }

    public void OpenAddtocartChicken(){
        Intent i = new Intent ();
        i.putExtra("ChickenPrice", 15);
        setResult(Activity.RESULT_OK,i);
        finish();
    }

}