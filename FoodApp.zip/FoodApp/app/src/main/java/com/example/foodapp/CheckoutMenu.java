package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CheckoutMenu extends AppCompatActivity {
    private Button NewOrder;
    private Button PayBill;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout_menu);

        int pay = getIntent().getExtras().getInt("Tpayment");
        TextView Finalbill=(TextView) findViewById(R.id.Money);
        Finalbill.setText("RM" + pay);

        NewOrder=(Button)findViewById(R.id.NewOrder);
        NewOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenNewOrder();
            }
        });

        PayBill=(Button)findViewById(R.id.Pay);
        PayBill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CallToast();
            }
        });

    }
    public void OpenNewOrder(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
    public void CallToast(){
        Context context = getApplicationContext();
        CharSequence text = "You have paid your bill.Your order shall be sent to the kitchen";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }
}